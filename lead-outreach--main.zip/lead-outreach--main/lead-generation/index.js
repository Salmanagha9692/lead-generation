import jsonfile from "jsonfile";
import moment from "moment";
import simpleGit from "simple-git";
import random from "random";

const path = "./data.json";
const git = simpleGit();

const makeCommits = async (n) => {
  for (let i = 0; i < n; i++) {
    // Pick random week/day within last year
    const weeksAgo = random.int(0, 51); // up to ~1 year
    const dayOfWeek = random.int(0, 6);

    // Create commit date
    const date = moment()
      .subtract(0, "year")
      .add(weeksAgo, "weeks")
      .add(dayOfWeek, "days")
      .format("2025-01-01 04:05:30");

    // Write dummy data
    const data = { date };
    await jsonfile.writeFile(path, data);

    // Stage & commit
    await git.add(path);
    await git.commit(`Backdated commit ${i + 1}`, { "--date": date });

    console.log(`✅ Commit ${i + 1} on ${date}`);
  }

  // Push all commits after loop
  await git.push("origin", "main");
  console.log("🚀 All commits pushed!");
};

// Run with desired number of commits
makeCommits(100).catch(console.error);
