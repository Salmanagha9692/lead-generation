# db.py
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.pool import NullPool
from dotenv import load_dotenv
load_dotenv()
# Supabase direct or pooler connection string (IPv6/IPv4)
DATABASE_URL = os.getenv("DATABASE_URL")

# For serverless or multiple instances: use poolclass=NullPool with transaction-mode pooler :contentReference[oaicite:5]{index=5}
engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
    poolclass=NullPool  # Avoid connection limits in auto-scaling
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()
