from pydantic_settings import BaseSettings, SettingsConfigDict
from functools import lru_cache
from typing import List

class SearchConfig(BaseSettings):
    TITLES: List[str] = ["CEO", "Founder", "Director", "CFO", "CMO"]
    INDUSTRIES: List[str] = [
        "Financial Services",
        "Luxury Goods & Jewelry",
        "Shipping",
        "Construction",
        "Automotive"
    ]
    LOCATIONS: List[str] = ["Barcelona, Spain"]
    PER_PAGE: int = 100

    class Config:
        env_file = ".env"

@lru_cache()
def get_search_config():
    return SearchConfig()
