from sqlalchemy import Column, String, Boolean, Integer, DateTime, func,ARRAY
from db import Base

class Lead(Base):
    __tablename__ = "leads"
    id = Column(String, primary_key=True)
    first_name = Column(String, nullable=True)
    email = Column(String, nullable=True)
    phone = Column(String, nullable=True)
    city = Column(String, nullable=True)
    senority = Column(String, nullable=True)
    curr_org_industry=Column(String, nullable=True)
    curr_org_estimated_num_employees=Column(String, nullable=True)
    lead_score=Column(Integer, nullable=True)
    lead_score_staus=Column(String, nullable=True)
    title= Column(String, nullable=True)
    linkedin_url = Column(String, nullable=True)
    company = Column(String, nullable=True)
    search_page = Column(Integer, nullable=True)
    search_order = Column(Integer, nullable=True)
    enriched = Column(Boolean, default=False)
    email_sent = Column(Boolean, default=False)
    email_opened  = Column(Boolean, default=False)
    email_clicked   = Column(Boolean, default=False)
    email_bounced   = Column(Boolean, default=False)
    email_delivered   = Column(Boolean, default=False)
    wa_sent = Column(Boolean, default=False)
    email_status = Column(String, nullable=True)
    wa_status = Column(String, nullable=True)
    created_at = Column(DateTime, server_default=func.now())

class SearchConfig(Base):
    __tablename__ = "search_config"

    key = Column(String, primary_key=True, index=True)
    titles = Column(ARRAY(String), nullable=False)
    industries = Column(ARRAY(String), nullable=False)
    locations = Column(ARRAY(String), nullable=False)
    per_page = Column(Integer, nullable=False, default=100)