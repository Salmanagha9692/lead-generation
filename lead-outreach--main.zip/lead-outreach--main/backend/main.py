from fastapi import FastAPI, HTTPException,Depends,Body,Query,Header,Request
from pydantic import BaseModel
from typing import List
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session
from sqlalchemy import select       
import io, csv
import json
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.date import DateTrigger
from apscheduler.triggers.cron import CronTrigger
from datetime import datetime
import httpx
from openai import OpenAI
import os, requests
from twilio.rest import Client
from signature_template import signature_html
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail, To
from pyairtable import Table
import  os
from dotenv import load_dotenv
from db import SessionLocal, Base, engine
from models import Lead as LeadModel
from models import SearchConfig
load_dotenv()  
app = FastAPI()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
# Initialize Twilio client
twilio_client = Client(os.getenv("TWILIO_ACCOUNT_SID"), os.getenv("TWILIO_AUTH_TOKEN"))
TWILIO_WHATSAPP_FROM = os.getenv("TWILIO_WHATSAPP_FROM")  
# --- Apollo configuration ---
APOLLO_KEY = os.getenv("APOLLO_API_KEY")
Base.metadata.create_all(bind=engine)
HEADERS = {
    "Content-Type": "application/json",
    "X-Api-Key": APOLLO_KEY
}
def generate_personalized_message(lead):
    messages = [
        {"role": "system", "content": "You are a professional luxury yacht sales assistant."},
        {"role": "user", "content": (
            f"Generate a formatted HTML email to {lead.first_name}, CEO at {lead.company}, their LinkedIn title is {lead.title}. "
            f"Use the following structure:\n\n"
            f"Hi {lead.first_name},\n\n"
            f"Your profile really caught my eye on LinkedIn, so I thought I’d reach out, I'm sure I can be of use.\n\n"
            "I’m Euan, a Yacht Sales Consultant at TWW Yachts, an industry-leading international brokerage firm based in Monaco and Barcelona. "
            "Given your background and success, I thought it would be worth introducing myself. Many founders and CEOs I work with appreciate having a trusted partner when they want to explore yachting, whether that’s a well-earned charter or the perfect yacht purchase to enhance your lifestyle or for investment purposes.\n\n"
            "Here’s a link to my introduction:\n"
            '<a clicktracking=off href="https://www.dropbox.com/scl/fi/'
            'mg2sny4c3wab2klewxf3b/Euan-Dodd-Consultant-Introduction.pdf?'
            'rlkey=tnkve03vferknl62ynqk9fiyn&dl=0">'
            "Euan Dodd – Consultant Introduction (PDF)</a>\n\n"
            "If yachting is something you’ve ever considered, or even just pondered, I’d be happy to have a quick chat or answer any questions. If not, this is a one off message, so you won't hear from me again, don't worry!.\n\n"
            "Best Regards\nEuan Dodd"
            f"please try to fall this email into inbox category instead of promotions category and do not show these words in the email"
        )}
    ]
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=messages,
        temperature=0.7,
    )
    print("response agya")
    return response.choices[0].message.content + signature_html









# --- Request model for bulk enrichment ---
# DB session dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.get("/check")
async def root():
    return {"message": "Hello World"}


@app.post("/search")
def search_phase1(page: int = 1,db: Session = Depends(get_db)):
    stmt = select(SearchConfig).where(SearchConfig.key == "phase1")
    cfg = db.execute(stmt).scalar_one_or_none()
    if not cfg:
        raise HTTPException(status_code=404, detail="No config found for phase1")
    payload = {
        "person_titles": cfg.titles,
        "person_industries": cfg.industries,
        "person_locations": cfg.locations,
        "per_page": cfg.per_page,
        "page": page,
        "person_signals": ["Luxury Yachting", "C Suite", "Recent funding"],
        "person_company_headcount_range": {"min": 50},
    }

    resp = requests.post(
        "https://api.apollo.io/api/v1/mixed_people/search",
        json=payload, headers=HEADERS
    )
    if resp.status_code != 200:
        raise HTTPException(status_code=resp.status_code, detail=resp.text)
  
    leads = resp.json().get("people", [])
     # Save to DB
    for idx, p in enumerate(leads):
        lead = db.get(LeadModel, p["id"]) or LeadModel(id=p["id"])
        lead.first_name = p.get("first_name")
        lead.city = p.get("city")
        lead.linkedin_url=p.get("linkedin_url")
        lead.title=p.get("title")
        history = p.get("employment_history", [])
        lead.company = history[0].get("organization_name") if history else None
        lead.search_page = page
        lead.search_order = idx
        db.add(lead)
    db.commit()
    return {"page": page, "list": leads}

@app.post("/apollo_phone_webhook")
async def apollo_phone_webhook(data: dict = Body(...), db: Session = Depends(get_db)):
    print ("webhook called")
    people = data.get("people", [])
    for p in people:
        lead = db.get(LeadModel, p.get("id"))
        if not lead:
            continue
        phones = p.get("phone_numbers", [])
        if phones:
            lead.phone = phones[0].get("sanitized_number")
            lead.wa_sent = False
        db.add(lead)
    db.commit()
    return {"received": len(people)}

@app.post("/bulk_enrich_batch")
def bulk_enrich_batch(db: Session = Depends(get_db)):
    leads_to_enrich = db.query(LeadModel).filter_by(enriched=False).order_by(LeadModel.search_page, LeadModel.search_order).limit(3).all()
    if not leads_to_enrich:
        return {"enriched_saved": 0, "message": "All leads enriched"}
    
    payload = {"details": [{"id": l.id} for l in leads_to_enrich], "reveal_personal_emails": True, "reveal_phone_number": True,"webhook_url": os.getenv("CALLBACK_URL")}
    resp = requests.post("https://api.apollo.io/api/v1/people/bulk_match",json=payload, headers=HEADERS)
    enriched = resp.json().get("matches", [])
    for e in enriched:
        lead = db.get(LeadModel, e["id"])
        lead.first_name = e.get("first_name")
        if not e.get("email"):
         continue
        lead.email = e.get("email")
        org = e.get("organization", {})
        lead.curr_org_industry=org.get("industry", "")
        lead.senority=e.get("seniority")
        lead.curr_org_estimated_num_employees=org.get("estimated_num_employees", 0)
        leadScore=compute_lead_scores({"title":e.get("title"),"seniority":e.get("seniority"),"curr_org_industry":org.get("industry", ""),"curr_org_estimated_num_employees":org.get("estimated_num_employees", 0)})
        print(leadScore)
        status = (
        "VIP" if leadScore >= 60 else
        "Warm" if leadScore >= 30 else
        "Cold"
        )
        lead.lead_score = leadScore
        lead.lead_score_staus = status
        
        lead.phone = (e.get("phone_numbers") or [{}])[0].get("raw_number")
        lead.linkedin_url = e.get("linkedin_url")
        lead.company = (e.get("employment_history") or [{}])[0].get("organization_name")
        lead.enriched = True
        db.add(lead)

    db.commit()
    return enriched

@app.post("/enrich_one_lead")
def enrich_one_lead(id: str = Query(...), reveal_email: bool = True, reveal_phone: bool = False, db: Session = Depends(get_db)):
    params = {
        "id": id,
        "reveal_personal_emails": reveal_email,
    }
    if reveal_phone:
        params["reveal_phone_number"] = True
        params["webhook_url"] = os.getenv("CALLBACK_URL")  # ensure your webhook URL is set

    # Call Apollo
    resp = requests.post("https://api.apollo.io/api/v1/people/match", params=params, headers=HEADERS)
    if resp.status_code != 200:
        raise HTTPException(status_code=resp.status_code, detail=resp.text)

    data = resp.json().get("person")
    if not data:
        raise HTTPException(404, "No person found")

    # Update database
    lead = db.get(LeadModel, id) or LeadModel(id=id)
    lead.first_name = data.get("first_name", lead.first_name)
    lead.email = data.get("email", lead.email)
    lead.phone = data.get("phone_numbers",lead.phone)
    lead.linkedin_url = data.get("linkedin_url",lead.linkedin_url)
    lead.company = ("employment_history",lead.company)
    lead.enriched = True
    # Note: Phone will arrive via webhook if reveal_phone=True
    db.add(lead)
    db.commit()

    return {"status": "enriched", "id": id, "data": data, **({"phone_requested": True} if reveal_phone else {})}


    
@app.post("/outreach_unsent_emails")
def outreach_unsent(limit: int = 10, db: Session = Depends(get_db)):
    leads = db.query(LeadModel)\
              .filter(LeadModel.email != None, LeadModel.email_sent == False)\
              .limit(limit).all()
    if not leads:
        return {"results": [], "message": "No unsent leads found or no email found to send."}
    sg = SendGridAPIClient(os.getenv("SENDGRID_API_KEY"))
    from_email = os.getenv("SENDGRID_SENDER_EMAIL")
    results = []
    for lead in leads:
        message = Mail(
            from_email=from_email,
            to_emails=[To(email=lead.email, name=lead.first_name)],
            subject=f"Connect with your Yachting Professional",
            html_content=generate_personalized_message(lead)
        )
        try:   
            resp = sg.send(message)
            lead.email_sent = True
            lead.email_status = str(resp.status_code)
        except Exception as e:
            lead.email_status = str(e)

        db.add(lead)
        db.commit()
        results.append({"id": lead.id, "email_status": lead.email_status})

    return {"results": results}

@app.post("/outreach_whatsapp")
def outreach_whatsapp(db: Session = Depends(get_db)):
    lead = db.query(LeadModel).filter(LeadModel.phone.isnot(None)).first()
    if not lead:
        return {"sent": 0, "message": "No valid high-priority leads with phone numbers."}
    result = twilio_client.messages.create(
        body="hello",
        from_=TWILIO_WHATSAPP_FROM,
        to=f"whatsapp:{lead.phone}",
        content_sid="HXdd052f8a226a23674042b1e8fca96b20",  # your approved template SID
        content_variables=json.dumps({"1": "Ali", "2": "25 June 2025"})
    )
    print(lead.phone)
    print(result)
    return {"sent": 1, "sid": result.sid}


@app.post("/sendgrid_webhook")
async def sendgrid_webhook(request: Request, x_signature: str = Header(None), db: Session = Depends(get_db)):
    payload = await request.body()

    # # Verify signature if enabled in SendGrid settings
    # secret = os.getenv("SENDGRID_WEBHOOK_SECRET")
    # if secret:
    #     expected = hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
    #     if not hmac.compare_digest(expected, x_signature or ""):
    #         raise HTTPException(status_code=400, detail="Invalid signature")

    events = await request.json()
    print(events)
    notified = []
    for ev in events:
        msg_id = ev.get("sg_message_id")
        evt = ev.get("event")
        lead = db.query(LeadModel).filter_by(sg_message_id=msg_id).first()
        if not lead:
            continue

        # Map SendGrid events to flags
        if evt == "open":
            lead.email_opened = True
        elif evt == "click":
            lead.email_clicked = True
        elif evt == "bounce":
            lead.email_bounced = True
        elif evt == "delivered":
            lead.email_delivered = True

        db.add(lead)
        notified.append((lead.id, evt))

    db.commit()
    # Optionally notify Slack/you about key events
    # for lead_id, evt in notified:
    #     if evt in ("click", "open"):
    #         notify_slack(f"Lead {lead_id} just {evt}ed an email!")

    return {"processed": len(notified)}

@app.get("/leads")
def get_leads(db: Session = Depends(get_db)):
    leads = db.query(LeadModel).all()
    return leads

class SearchConfigIn(BaseModel):
    key: str
    titles: List[str]
    industries: List[str]
    locations: List[str]
    per_page: int
@app.post("/search_config/upsert",response_model=SearchConfigIn)
def upsert_search_config(conf:SearchConfigIn, db: Session = Depends(get_db)):
    stmt = insert(SearchConfig).values(
        key=conf.key,
        titles=conf.titles,
        industries=conf.industries,
        locations=conf.locations,
        per_page=conf.per_page
    ).on_conflict_do_update(
        index_elements=["key"],
        set_={
            "titles": conf.titles,
            "industries": conf.industries,
            "locations": conf.locations,
            "per_page": conf.per_page
        }
    )
    db.execute(stmt)
    db.commit()

    updated = db.query(SearchConfig).get(conf.key)
    if not updated:
        raise HTTPException(status_code=500, detail="Failed to upsert config")
    return updated

@app.post("/sync_to_airtable")
def sync_to_airtable():
    sync_url = os.getenv("AIRTABLE_SYNC_URL")
    pat = os.getenv("AIRTABLE_SYNC_PAT")
    if not sync_url or not pat:
        raise HTTPException(status_code=500, detail="Missing Airtable sync config")

    # Fetch data from D
    db: Session = SessionLocal()
    leads = db.execute(select(LeadModel)).scalars().all()
    # Convert to CSV
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["id", "Name","Score","Score Status","linkedin_url","title","company","email_opened","email_clicked","city","email_bounced","email","email_delivered","phone","search_page","wa_sent","search_order","enriched","wa_status","email_sent"])
    for lead in leads:
        writer.writerow([lead.id, lead.first_name,lead.lead_score,lead.lead_score_staus,lead.linkedin_url,lead.title,lead.company,lead.email_opened,lead.email_clicked,lead.city,lead.email_bounced,lead.email,lead.email_delivered,lead.phone,lead.search_page,lead.wa_sent,lead.search_order,lead.enriched,lead.wa_status,lead.email_sent])
    # return buf.getvalue()
    # Send to Airtable Sync API
    resp = requests.post(
        sync_url,
        headers={
            "Authorization": f"Bearer {pat}",
            "Content-Type": "text/csv"
        },
        data=buf.getvalue() 
    )
    if resp.status_code != 200:
        raise HTTPException(status_code=resp.status_code, detail=resp.text)
    print("here")
    return {"synced": resp}

def compute_lead_scores(lead):
        print(lead)
    # def score(lead):
        s = 0

        # Get seniority safely
        seniority = lead.get("seniority") if isinstance(lead, dict) else getattr(lead, "seniority", None)
        if seniority == "c_suite":
            s += 40
        elif seniority and "founder" in seniority:
            s += 30

        # Title
        title = lead.get("title") if isinstance(lead, dict) else getattr(lead, "title", None)
        t = (title or "").lower()
        if any(x in t for x in ["ceo", "cfo", "coo", "cto"]):
            s += 20
        elif any(x in t for x in ["director", "founder"]):
            s += 10

        # Industry
        ind = (lead.get("curr_org_industry") if isinstance(lead, dict) else getattr(lead, "curr_org_industry", None) or "").lower()
        if "yacht" in ind or "maritime" in ind:
            s += 15
        elif "luxury" in ind or "hospitality" in ind:
            s += 8

        # Company size
        size_raw = lead.get("curr_org_estimated_num_employees") if isinstance(lead, dict) else getattr(lead, "curr_org_estimated_num_employees", None)
        try:
            size = int(size_raw) or 0
        except (TypeError, ValueError):
            size = 0

        if size >= 200:
            s += 10
        elif size >= 50:
            s += 5

        return s


@app.get("/leads/score")
def get_lead_score(lead_id:str = Query(...) , db: Session = Depends(get_db)):
    lead = db.query(LeadModel).filter(LeadModel.id == lead_id, LeadModel.enriched == True).first()
    if not lead:
        raise HTTPException(status_code=404, detail="Lead not found")
    obj=[{'title': 'Co-founder & CFO', 'seniority': 'founder', 'curr_org_industry': 'financial services', 'curr_org_estimated_num_employees': 490}]
    score = compute_lead_scores(obj)
    print(score)
    status = (
        "VIP" if score >= 60 else
        "Warm" if score >= 30 else
        "Cold"
    )
    lead.lead_score = score
    lead.lead_score_staus = status
    db.commit()
    return {
        "id": lead.id,
        "title": lead.title,
        "seniority": lead.senority,
        "industry": lead.curr_org_industry,
        "employees": lead.curr_org_estimated_num_employees,
        "score": score,
        "status": status
    }
    
@app.post("/whatsapp-incoming-replies")
async def incoming(request: Request):
    form = await request.form()
    from_num = form.get("From")
    body = form.get("Body")
    from_email = os.getenv("SENDGRID_SENDER_EMAIL")
    sg = SendGridAPIClient(os.getenv("SENDGRID_API_KEY"))
    message = Mail(
            from_email=from_email,
            to_emails=[To(email="ahmedsheraz124@gmail.com", name="sheraz ahmed")],
            subject=f"Connect with your Yachting Professional",
            plain_text_content="Hi Euan You receive a reply from {from_num} . Message is {body} "
    )
    try:   
            resp = sg.send(message)
    except Exception as e:
        print(e)
    print(form)
    return 