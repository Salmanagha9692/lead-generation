# signature_template.py

signature_html = """
<!DOCTYPE html><html><body style="font-family: Arial, sans-serif; margin:0; padding:20px; background-color:#f5f5f5;">
<div style="max-width:600px; margin:auto; background:white; padding:20px;">
<div style="max-width:600px;background:white;border:1px solid #ddd;font-family:Arial,sans-serif;">
  <div style="display:flex;align-items:center;padding:15px;background:#fff;">
    <div style="width:120px;height:120px;margin-right:20px;border-radius:5px;">
      <img src="https://lh3.googleusercontent.com/d/10FbQODdWXSGe09nIU9AdLbxHq46a0adX" alt="TWW Yachts Logo"
           style="width:100%;height:100%;object-fit:contain;">
    </div>
    <div style="flex:1;">
      <div style="font-size:18px;font-weight:bold;color:#1e3a8a;margin-bottom:5px;">Euan Dodd</div>
      <div style="font-size:16px;color:#1e3a8a;margin-bottom:15px;">Sales Broker</div>
      <div style="font-size:14px;line-height:1.4;color:#333;">
        <div>m: +44 7448 828938</div>
        <div>o: +377 97 77 67 57</div>
        <div><a href="mailto:euan@twwyachts.com" style="color:#1e3a8a;text-decoration:none;">euan@twwyachts.com</a></div>
        <div><a href="https://twwyachts.com" style="color:#1e3a8a;text-decoration:none;">twwyachts.com</a></div>
        <div><a href="https://wa.me/+447448828938" target="_blank" style="color:#1e3a8a; text-decoration:none;">WhatsApp</a></div>
      </div>
      <div style="margin-top:10px;font-size:13px;color:#666;">
        <a href="#" style="color:#1e3a8a;text-decoration:none;">57 rue Grimaldi, MC98000, Monaco</a>
      </div>
    </div>
  </div>
  <div style="padding:10px 15px;background:#f8f9fa;border-top:1px solid #ddd;border-bottom:1px solid #ddd;
              text-align:left;font-size:13px;color:#666;font-weight:500;">
    <a href="https://www.twwyachts.com/luxury-yachts-for-sale/" target="_blank" style="color:#666;text-decoration:none;margin-right:8px;">SALES & PURCHASE</a>|
    <a href="https://www.twwyachts.com/yachts-for-charter/" target="_blank" style="color:#666;text-decoration:none;margin:0 8px;">CHARTER</a>|
    <a href="https://www.twwyachts.com/superyacht-management/" target="_blank" style="color:#666;text-decoration:none;margin:0 8px;">MANAGEMENT</a>|
    <a href="https://www.twwyachts.com/superyacht-construction/" target="_blank" style="color:#666;text-decoration:none;margin:0 8px;">BUILD</a>|
    <a href="https://www.twwyachts.com/yacht-crew/" target="_blank" style="color:#666;text-decoration:none;margin-left:8px;">CREW</a>
  </div>
  <div style="display:flex;height:180px;">
    <div style="flex:1;text-align:center;">
      <a href="https://www.twwyachts.com/luxury-yachts-for-sale/" target="_blank">
        <img src="https://lh3.googleusercontent.com/d/1XSE79G5tQKMiAiuAKRlwRA_0RwuHhiYn"
             alt="Charter Fleet"
             style="width:100%;height:180px;object-fit:cover;">
      </a>
    </div>
    <div style="flex:1;text-align:center;">
      <img src="https://lh3.googleusercontent.com/d/1vTouuDROJoeU1ret_BEjOziXT7psFoRc" alt="Sales Market"
           style="width:100%;height:180px;object-fit:cover;">
    </div>
  </div>
</div>
</div></body></html>
"""
